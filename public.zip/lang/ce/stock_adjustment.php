<?php

 return [
     'stock_adjustment' => '庫存更正',
     'stock_adjustments' => '庫存調整',
     'list' => '列出庫存調整',
     'add' => '添加庫存調整',
     'all_stock_adjustments' => '所有庫存調整',
     'search_product' => '搜索庫存匹配產品',
     'adjustment_type' => '調整類型',
     'normal' => 'normal',
     'abnormal' => '異常',
     'total_amount' => '總金額',
     'total_amount_recovered' => '總回收率',
     'reason_for_stock_adjustment' => '理由',
     'stock_adjustment_added_successfully' => '庫存調整成功添加',
     'search_products' => '產品搜索',
     'delete_success' => '庫存調整已成功刪除',
     'view_details' => '顯示庫存調整詳情',
 ];
