<?php

 return [
     'stock_adjustment' => 'Bestandskorrektur',
     'stock_adjustments' => 'Bestandsanpassungen',
     'list' => 'Bestandsanpassungen auflisten',
     'add' => 'Bestandsanpassung hinzufügen',
     'all_stock_adjustments' => 'Alle Bestandsanpassungen',
     'search_product' => 'Produkte zur Bestandsanpassung suchen',
     'adjustment_type' => 'Anpassungsart',
     'normal' => 'Normal',
     'abnormal' => 'Abnormal',
     'total_amount' => 'Gesamtmenge',
     'total_amount_recovered' => 'Gesamtmenge wiedergewonnen',
     'reason_for_stock_adjustment' => 'Grund',
     'stock_adjustment_added_successfully' => 'Bestandsanpassung erfolgreich hinzugefügt',
     'search_products' => 'Produktsuche',
     'delete_success' => 'Bestandsanpassung erfolgreich gelöscht',
     'view_details' => 'Details zur Bestandsanpassung anzeigen',
 ];
