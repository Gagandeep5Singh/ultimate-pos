<?php

 return [
     'product' => '產品',
     'qty' => '數量',
     'unit_price' => '單價',
     'subtotal' => '小計',
     'discount' => '折扣',
     'tax' => '增值稅',
     'total' => '總數',
     'invoice_number' => '發票編號',
     'date' => 'date',
     'receipt_settings' => '接收設置',
     'receipt_settings_mgs' => '此位置的所有與接收相關的設置',
     'print_receipt_on_invoice' => '完成後自動打印發票',
     'receipt_printer_type' => '收據打印機類型',
     'receipt_settings_updated' => '收據更新已成功更新',
 ];
