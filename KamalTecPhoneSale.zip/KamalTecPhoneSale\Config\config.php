﻿<?php

return [
    'name' => 'KamalTecPhoneSale',
    'module_version' => '1.0',
];
